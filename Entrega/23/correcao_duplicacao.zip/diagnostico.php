<?php
require_once 'config.php';
$pdo = Config::getDbConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deletar_id'])) {
    $id = intval($_POST['deletar_id']);
    $pdo->prepare("DELETE FROM produtos WHERE id = ?")->execute([$id]);
    echo "<script>location.href=location.href</script>";
    exit;
}

$produtos = $pdo->query("SELECT id, nome, fabricante, categoria, preco_venda, ativo FROM produtos ORDER BY nome, id")->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Diagnóstico</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head><body class="p-4">
<h4>Todos os produtos no banco</h4>
<table class="table table-bordered table-sm">
<thead class="table-dark"><tr><th>ID</th><th>Nome</th><th>Fabricante</th><th>Categoria</th><th>Preço</th><th>Ativo</th><th>Ação</th></tr></thead>
<tbody>
<?php foreach ($produtos as $p): ?>
<tr class="<?= $p['ativo'] == 0 ? 'table-danger' : '' ?>">
  <td><?= $p['id'] ?></td>
  <td><?= htmlspecialchars($p['nome']) ?></td>
  <td><?= htmlspecialchars($p['fabricante']) ?></td>
  <td><?= htmlspecialchars($p['categoria']) ?></td>
  <td>R$ <?= number_format($p['preco_venda'],2,',','.') ?></td>
  <td><?= $p['ativo'] ? '✅ Sim' : '❌ Não' ?></td>
  <td>
    <form method="POST" onsubmit="return confirm('Deletar ID <?= $p['id'] ?> (<?= htmlspecialchars($p['nome']) ?>)?')">
      <input type="hidden" name="deletar_id" value="<?= $p['id'] ?>">
      <button class="btn btn-danger btn-sm">🗑 Deletar</button>
    </form>
  </td>
</tr>
<?php endforeach; ?>
</tbody></table>
<p class="text-muted">Após limpar, apague este arquivo do servidor.</p>
</body></html>
