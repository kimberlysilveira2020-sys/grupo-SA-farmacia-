<?php
class UsuarioModel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Config::getDbConnection();
    }

    public function buscarPorLogin(string $login): ?array {
        $stmt = $this->pdo->prepare("SELECT id, nome, login, senha_hash, cargo FROM usuarios WHERE login = ?");
        $stmt->execute([$login]);
        return $stmt->fetch() ?: null;
    }

    public function criar(string $nome, string $login, string $senha, string $cargo): array {
        $stmtCheck = $this->pdo->prepare("SELECT id FROM usuarios WHERE login = ?");
        $stmtCheck->execute([$login]);
        if ($stmtCheck->fetch()) {
            return ['success' => false, 'message' => 'Este usuário/login já está em uso. Escolha outro.'];
        }
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare("INSERT INTO usuarios (nome, login, senha_hash, cargo) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $login, $senhaHash, $cargo]);
        return ['success' => true];
    }
}
