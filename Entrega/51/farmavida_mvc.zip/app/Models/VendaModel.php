<?php
class VendaModel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Config::getDbConnection();
    }

    public function getCaixaAberto(int $usuarioId): ?array {
        $stmt = $this->pdo->prepare("SELECT * FROM caixa WHERE usuario_id = ? AND status = 'aberto' ORDER BY aberto_em DESC LIMIT 1");
        $stmt->execute([$usuarioId]);
        return $stmt->fetch() ?: null;
    }

    public function getTotaisCaixa(int $caixaId): array {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) AS qtd, COALESCE(SUM(total),0) AS soma FROM vendas WHERE caixa_id = ?");
        $stmt->execute([$caixaId]);
        return $stmt->fetch();
    }

    public function listar(string $data1, string $data2): array {
        $stmt = $this->pdo->prepare("
            SELECT v.id, v.data_venda, v.total, v.supervisor_liberacao,
                   u.nome AS vendedor, u.cargo AS cargo_vendedor,
                   c.nome AS cliente_nome, cx.id AS caixa_id
            FROM vendas v
            INNER JOIN usuarios u ON v.usuario_id = u.id
            LEFT JOIN clientes c ON v.cliente_id = c.id
            LEFT JOIN caixa cx ON v.caixa_id = cx.id
            WHERE DATE(v.data_venda) BETWEEN ? AND ?
            ORDER BY v.data_venda DESC
        ");
        $stmt->execute([$data1, $data2]);
        return $stmt->fetchAll();
    }

    public function getHistoricoCaixas(): array {
        $stmt = $this->pdo->prepare("
            SELECT cx.*, u.nome AS operador,
                   COUNT(v.id) AS qtd_vendas, COALESCE(SUM(v.total),0) AS total_vendas
            FROM caixa cx
            INNER JOIN usuarios u ON cx.usuario_id = u.id
            LEFT JOIN vendas v ON v.caixa_id = cx.id
            GROUP BY cx.id ORDER BY cx.aberto_em DESC LIMIT 20
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function finalizar(array $itens, int $usuarioId, ?string $supervisor, ?int $clienteId, ?int $caixaId): array {
        if ($supervisor && $supervisor !== Config::SENHA_SUPERVISOR_MESTRA) {
            return ['success' => false, 'message' => 'Senha do supervisor incorreta!'];
        }
        $this->pdo->beginTransaction();
        try {
            $total = array_sum(array_map(fn($i) => $i['quantidade'] * $i['preco'], $itens));
            $stmt = $this->pdo->prepare("INSERT INTO vendas (total, usuario_id, supervisor_liberacao, cliente_id, caixa_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$total, $usuarioId, $supervisor, $clienteId, $caixaId]);
            $vendaId = $this->pdo->lastInsertId();

            $stmtItem    = $this->pdo->prepare("INSERT INTO itens_venda (venda_id, produto_id, lote_id, quantidade, preco) VALUES (?, ?, ?, ?, ?)");
            $stmtEstoque = $this->pdo->prepare("UPDATE lotes SET qtd_atual = qtd_atual - ? WHERE id = ?");
            $stmtLote    = $this->pdo->prepare("SELECT id, qtd_atual FROM lotes WHERE produto_id = ? AND qtd_atual >= ? ORDER BY data_validade ASC LIMIT 1");

            foreach ($itens as $item) {
                $stmtLote->execute([$item['produto_id'], $item['quantidade']]);
                $lote = $stmtLote->fetch();
                if (!$lote) throw new \Exception("Estoque insuficiente para {$item['nome']}.");
                $stmtItem->execute([$vendaId, $item['produto_id'], $lote['id'], $item['quantidade'], $item['preco']]);
                $stmtEstoque->execute([$item['quantidade'], $lote['id']]);
            }
            $this->pdo->commit();
            return ['success' => true, 'venda_id' => $vendaId];
        } catch (\Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function getItens(int $vendaId): array {
        $s = $this->pdo->prepare("
            SELECT iv.quantidade, iv.preco, p.nome AS produto_nome
            FROM itens_venda iv INNER JOIN produtos p ON iv.produto_id = p.id
            WHERE iv.venda_id = ?
        ");
        $s->execute([$vendaId]);
        return $s->fetchAll();
    }

    public function abrirCaixa(int $usuarioId, float $valor, ?string $obs): array {
        $chk = $this->pdo->prepare("SELECT id FROM caixa WHERE usuario_id=? AND status='aberto'");
        $chk->execute([$usuarioId]);
        if ($chk->fetch()) return ['success' => false, 'message' => 'Você já possui um caixa aberto.'];
        $s = $this->pdo->prepare("INSERT INTO caixa (usuario_id,valor_abertura,observacao,status) VALUES (?,?,?,'aberto')");
        $s->execute([$usuarioId, $valor, $obs]);
        return ['success' => true, 'caixa_id' => $this->pdo->lastInsertId()];
    }

    public function fecharCaixa(int $id, int $usuarioId, float $valor, ?string $obs): array {
        $s = $this->pdo->prepare("UPDATE caixa SET status='fechado', valor_fechamento=?, fechado_em=NOW(), observacao=CONCAT(COALESCE(observacao,''),' | Fechamento: ',?) WHERE id=? AND usuario_id=?");
        $s->execute([$valor, $obs ?? '', $id, $usuarioId]);
        return ['success' => true];
    }
}
