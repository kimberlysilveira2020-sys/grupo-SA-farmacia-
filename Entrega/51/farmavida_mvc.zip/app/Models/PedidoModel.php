<?php
class PedidoModel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Config::getDbConnection();
    }

    public function listar(string $status = '', string $busca = ''): array {
        $where  = ['1=1'];
        $params = [];
        if ($status && $status !== 'todos') {
            $where[] = 'p.status = :status';
            $params[':status'] = $status;
        }
        if ($busca) {
            $where[] = '(cl.nome LIKE :busca OR p.id = :pid OR cl.email LIKE :busca2)';
            $params[':busca']  = "%$busca%";
            $params[':busca2'] = "%$busca%";
            $params[':pid']    = is_numeric($busca) ? (int)$busca : 0;
        }
        $whereSQL = implode(' AND ', $where);
        $stmt = $this->pdo->prepare("
            SELECT p.id, p.status, p.total, p.forma_pagamento, p.pix_pago,
                   p.boleto_codigo, p.boleto_vencimento, p.pix_txid, p.criado_em,
                   cl.nome AS cliente_nome, cl.email AS cliente_email, cl.telefone AS cliente_tel,
                   COUNT(pi.id) AS qtd_itens
            FROM pedidos p
            INNER JOIN clientes_loja cl ON cl.id = p.cliente_id
            LEFT JOIN pedido_itens pi ON pi.pedido_id = p.id
            WHERE $whereSQL GROUP BY p.id ORDER BY p.criado_em DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getResumo(): array {
        $tots = $this->pdo->query("
            SELECT status, COUNT(*) AS qtd, COALESCE(SUM(total),0) AS soma FROM pedidos GROUP BY status
            UNION ALL
            SELECT 'total_geral' AS status, COUNT(*) AS qtd, COALESCE(SUM(total),0) AS soma FROM pedidos
        ")->fetchAll(PDO::FETCH_ASSOC);
        $resumo = [];
        foreach ($tots as $t) $resumo[$t['status']] = $t;
        return $resumo;
    }

    public function getDetalhes(int $id): ?array {
        $p = $this->pdo->prepare("
            SELECT p.*, cl.nome AS cliente_nome, cl.email AS cliente_email,
                   cl.telefone AS cliente_tel, cl.cpf AS cliente_cpf
            FROM pedidos p INNER JOIN clientes_loja cl ON cl.id = p.cliente_id WHERE p.id = ?
        ");
        $p->execute([$id]);
        $pedido = $p->fetch();
        if (!$pedido) return null;
        $itens = $this->pdo->prepare("
            SELECT pi.quantidade, pi.preco, pr.nome AS produto_nome, pr.fabricante, pr.categoria
            FROM pedido_itens pi INNER JOIN produtos pr ON pr.id = pi.produto_id WHERE pi.pedido_id = ?
        ");
        $itens->execute([$id]);
        $pedido['itens'] = $itens->fetchAll();
        return $pedido;
    }

    public function atualizarStatus(int $id, string $status): bool {
        $this->pdo->prepare("UPDATE pedidos SET status=? WHERE id=?")->execute([$status, $id]);
        return true;
    }

    public function confirmarPix(int $id): bool {
        $this->pdo->prepare("UPDATE pedidos SET pix_pago=1, status='confirmado' WHERE id=?")->execute([$id]);
        return true;
    }

    public function deletar(int $id): bool {
        $this->pdo->prepare("DELETE FROM pedido_itens WHERE pedido_id=?")->execute([$id]);
        $this->pdo->prepare("DELETE FROM pedidos WHERE id=?")->execute([$id]);
        return true;
    }
}
