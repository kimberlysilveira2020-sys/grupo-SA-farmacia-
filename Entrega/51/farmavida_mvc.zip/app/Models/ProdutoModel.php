<?php
class ProdutoModel {
    private PDO $pdo;

    public function __construct() {
        $this->pdo = Config::getDbConnection();
        $this->ensureSchema();
    }

    private function ensureSchema(): void {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS `categorias` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `nome` varchar(100) NOT NULL,
              `icone` varchar(50) DEFAULT 'bi-tag',
              `ativo` tinyint(1) DEFAULT 1,
              `ordem` int(11) DEFAULT 0,
              `criado_em` datetime DEFAULT current_timestamp(),
              PRIMARY KEY (`id`),
              UNIQUE KEY `nome` (`nome`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");
        $qtd = (int)$this->pdo->query("SELECT COUNT(*) FROM categorias")->fetchColumn();
        if ($qtd === 0) {
            $this->pdo->exec("
                INSERT IGNORE INTO `categorias` (`nome`, `icone`, `ordem`) VALUES
                ('Comum','bi-capsule',1),('Genérico','bi-capsule-pill',2),
                ('Controlado','bi-shield-lock',3),('Antibiótico','bi-bacteria',4),
                ('Vitaminas','bi-heart',5),('Suplementos','bi-activity',6),
                ('Dermocosméticos','bi-stars',7),('Higiene','bi-droplet',8),
                ('Beleza','bi-flower1',9),('Infantil','bi-emoji-smile',10),
                ('Ortopédico','bi-bandaid',11),('Hospitalar','bi-hospital',12)
            ");
        }
        $colAtivo = $this->pdo->query("SHOW COLUMNS FROM produtos LIKE 'ativo'")->fetchAll();
        if (empty($colAtivo)) {
            $this->pdo->exec("ALTER TABLE produtos ADD COLUMN `ativo` TINYINT(1) NOT NULL DEFAULT 1");
            $this->pdo->exec("UPDATE produtos SET ativo = 1 WHERE ativo IS NULL");
        }
        try {
            $this->pdo->exec("
                DELETE FROM produtos
                WHERE COALESCE(ativo,1) = 0
                  AND id NOT IN (SELECT DISTINCT produto_id FROM itens_venda)
                  AND id NOT IN (SELECT DISTINCT produto_id FROM pedido_itens)
            ");
        } catch (\Exception $e) {}
    }

    public function getCategorias(): array {
        return $this->pdo->query("SELECT * FROM categorias WHERE ativo=1 ORDER BY ordem ASC, nome ASC")->fetchAll();
    }

    public function getPaginado(string $busca, string $catFiltro, int $pagina, int $porPag): array {
        $offset = ($pagina - 1) * $porPag;
        $where  = ["p.ativo = 1"];
        $params = [];
        if ($busca)     { $where[] = "(p.nome LIKE ? OR p.fabricante LIKE ?)"; $params[] = "%$busca%"; $params[] = "%$busca%"; }
        if ($catFiltro) { $where[] = "p.categoria = ?"; $params[] = $catFiltro; }
        $whereSQL = 'WHERE ' . implode(' AND ', $where);

        $stC = $this->pdo->prepare("SELECT COUNT(*) FROM produtos p $whereSQL");
        $stC->execute($params);
        $total = (int)$stC->fetchColumn();

        $stP = $this->pdo->prepare("
            SELECT p.id, p.nome, p.fabricante, p.categoria, p.preco_venda, p.receita_obrigatoria, p.foto,
                   COALESCE(SUM(l.qtd_atual),0) AS estoque_total, COUNT(l.id) AS num_lotes
            FROM produtos p
            LEFT JOIN lotes l ON l.produto_id = p.id AND l.qtd_atual > 0
            $whereSQL GROUP BY p.id ORDER BY p.nome ASC LIMIT $porPag OFFSET $offset
        ");
        $stP->execute($params);
        return ['lista' => $stP->fetchAll(), 'total' => $total, 'totalPags' => max(1, ceil($total / $porPag))];
    }

    public function criar(array $d, ?string $foto): array {
        $this->pdo->beginTransaction();
        try {
            $chk = $this->pdo->prepare("SELECT id, ativo FROM produtos WHERE nome = ? AND fabricante = ? LIMIT 1 FOR UPDATE");
            $chk->execute([$d['nome'], $d['fabricante']]);
            $existente = $chk->fetch();
            if ($existente) {
                if ((int)$existente['ativo'] === 1) {
                    $this->pdo->rollBack();
                    return ['success' => false, 'message' => 'Já existe um produto com este nome e fabricante.'];
                }
                $produtoId = (int)$existente['id'];
                $s = $this->pdo->prepare("UPDATE produtos SET categoria=?, preco_venda=?, descricao=?, ativo=1" . ($foto ? ", foto=?" : "") . " WHERE id=?");
                $p = [$d['categoria'], $d['preco_venda'], $d['descricao']];
                if ($foto) $p[] = $foto;
                $p[] = $produtoId;
                $s->execute($p);
            } else {
                $stmt = $this->pdo->prepare("INSERT INTO produtos (nome, fabricante, categoria, preco_venda, descricao, foto, ativo) VALUES (?, ?, ?, ?, ?, ?, 1)");
                $stmt->execute([$d['nome'], $d['fabricante'], $d['categoria'], $d['preco_venda'], $d['descricao'], $foto]);
                $produtoId = (int)$this->pdo->lastInsertId();
            }
            if (!empty($d['lote_numero']) && !empty($d['lote_validade']) && (int)($d['lote_quantidade'] ?? 0) > 0) {
                $stmtL = $this->pdo->prepare("INSERT INTO lotes (produto_id, numero_lote, data_validade, qtd_atual, qtd_inicial) VALUES (?, ?, ?, ?, ?)");
                $qtd = (int)$d['lote_quantidade'];
                $stmtL->execute([$produtoId, $d['lote_numero'], $d['lote_validade'], $qtd, $qtd]);
            }
            $this->pdo->commit();
            return ['success' => true, 'produto_id' => $produtoId];
        } catch (\PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function editar(array $d, ?string $foto): bool {
        if ($foto) {
            $old = $this->pdo->prepare("SELECT foto FROM produtos WHERE id = ?");
            $old->execute([$d['id']]);
            $oldFoto = $old->fetchColumn();
            if ($oldFoto && file_exists(__DIR__ . '/../../uploads/produtos/' . $oldFoto)) {
                @unlink(__DIR__ . '/../../uploads/produtos/' . $oldFoto);
            }
            $stmt = $this->pdo->prepare("UPDATE produtos SET nome=?, fabricante=?, categoria=?, preco_venda=?, descricao=?, foto=? WHERE id=?");
            $stmt->execute([$d['nome'], $d['fabricante'], $d['categoria'], $d['preco_venda'], $d['descricao'], $foto, $d['id']]);
        } else {
            $stmt = $this->pdo->prepare("UPDATE produtos SET nome=?, fabricante=?, categoria=?, preco_venda=?, descricao=? WHERE id=?");
            $stmt->execute([$d['nome'], $d['fabricante'], $d['categoria'], $d['preco_venda'], $d['descricao'], $d['id']]);
        }
        return true;
    }

    public function deletar(int $id): array {
        $chkV = $this->pdo->prepare("SELECT COUNT(*) FROM itens_venda WHERE produto_id = ?"); $chkV->execute([$id]);
        $chkP = $this->pdo->prepare("SELECT COUNT(*) FROM pedido_itens WHERE produto_id = ?"); $chkP->execute([$id]);
        $temV = (int)$chkV->fetchColumn() > 0;
        $temP = (int)$chkP->fetchColumn() > 0;
        if ($temV || $temP) {
            $this->pdo->prepare("UPDATE produtos SET ativo = 0 WHERE id = ?")->execute([$id]);
            $origens = [];
            if ($temV) $origens[] = 'vendas internas';
            if ($temP) $origens[] = 'pedidos da loja';
            return ['success' => true, 'aviso' => 'Produto desativado pois possui ' . implode(' e ', $origens) . ' vinculadas.'];
        }
        $this->pdo->prepare("DELETE FROM lotes WHERE produto_id = ?")->execute([$id]);
        $old = $this->pdo->prepare("SELECT foto FROM produtos WHERE id = ?"); $old->execute([$id]);
        $fotoNome = $old->fetchColumn();
        if ($fotoNome && file_exists(__DIR__ . '/../../uploads/produtos/' . $fotoNome)) {
            @unlink(__DIR__ . '/../../uploads/produtos/' . $fotoNome);
        }
        $this->pdo->prepare("DELETE FROM produtos WHERE id = ?")->execute([$id]);
        return ['success' => true];
    }

    public function getLotes(int $produtoId): array {
        $stmt = $this->pdo->prepare("SELECT id, numero_lote, data_validade, qtd_atual, DATEDIFF(data_validade, CURDATE()) AS dias_para_vencer, CASE WHEN data_validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END AS vencendo FROM lotes WHERE produto_id = ? ORDER BY data_validade ASC");
        $stmt->execute([$produtoId]);
        return $stmt->fetchAll();
    }

    public function criarLote(array $d): bool {
        $stmt = $this->pdo->prepare("INSERT INTO lotes (produto_id, numero_lote, data_validade, qtd_atual, qtd_inicial) VALUES (?, ?, ?, ?, ?)");
        $qtd = (int)$d['qtd_atual'];
        $stmt->execute([(int)$d['produto_id'], trim($d['numero_lote']), $d['data_validade'], $qtd, $qtd]);
        return true;
    }

    public function criarCategoria(string $nome, string $icone): int {
        $s = $this->pdo->prepare("INSERT INTO categorias (nome, icone) VALUES (?, ?)");
        $s->execute([$nome, $icone]);
        return (int)$this->pdo->lastInsertId();
    }

    public function removerCategoria(int $id): bool {
        $this->pdo->prepare("DELETE FROM categorias WHERE id=?")->execute([$id]);
        return true;
    }
}
