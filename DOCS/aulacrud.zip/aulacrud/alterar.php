<?php
require('conexao.php');


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = filter_input(INPUT_GET, 'id');
    
    $sql = "SELECT * FROM cadastro WHERE id = :id";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':id', $id);
    $statement->execute();
    $usuario = $statement->fetch(PDO::FETCH_ASSOC);
    

    ?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Alterar Usuário</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container mt-5">
        <h2>Alterar Dados do Usuário</h2>
        <form action="alterar.php" method="post">
            <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
            
            <input class="form-control mb-2" type="text" name="nome" value="<?php echo $usuario['Nome']; ?>">
            <input class="form-control mb-2" type="text" name="sobrenome" value="<?php echo $usuario['Sobrenome']; ?>">
            <input class="form-control mb-2" type="date" name="datanasc" value="<?php echo $usuario['datanasc']; ?>">
            
            <input type="submit" value="Salvar Alterações" class="btn btn-success">
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </body>
    </html>
    <?php
} 


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id');
    $nome = filter_input(INPUT_POST, 'nome');
    $sobrenome = filter_input(INPUT_POST, 'sobrenome');
    $datanasc = filter_input(INPUT_POST, 'datanasc');

    try {
        $sql = "UPDATE cadastro SET nome = :nome, sobrenome = :sobrenome, datanasc = :datanasc WHERE id = :id";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(':nome', $nome);
        $statement->bindValue(':sobrenome', $sobrenome);
        $statement->bindValue(':datanasc', $datanasc);
        $statement->bindValue(':id', $id);
        $statement->execute();

        header('Location: index.php');
        exit();
    } catch (PDOException $e) {
        echo "Erro ao alterar: " . $e->getMessage();
        exit();
    }
}
?>