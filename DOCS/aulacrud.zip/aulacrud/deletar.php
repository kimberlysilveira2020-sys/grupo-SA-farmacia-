<?php
require('conexao.php');


$id = filter_input(INPUT_GET, 'id');

if ($id) {
    try {
        
        $sql = "DELETE FROM cadastro WHERE id = :id";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(':id', $id);
        $statement->execute();
        
 
        header('Location: index.php');
        exit();
        
    } catch (PDOException $e) {
        echo "Erro ao deletar usuário: " . $e->getMessage();
        exit();
    }
} else {
    
    header('Location: index.php');
    exit();
}
?>