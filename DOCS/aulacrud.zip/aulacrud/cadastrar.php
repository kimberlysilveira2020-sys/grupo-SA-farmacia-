<?php

require ('conexao.php');

$nome = filter_input(type:INPUT_POST, var_name:'nome');
$sobrenome = filter_input(type:INPUT_POST, var_name: 'sobrenome');
$datanasc = filter_input(type:INPUT_POST, var_name:'datanasc');

try {
     // Código de inserção no banco...
    $sql = "INSERT INTO cadastro (nome, sobrenome, datanasc) VALUES (:nome, :sobrenome, :datanasc)";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':nome', $nome);
    $statement->bindValue(':sobrenome', $sobrenome);    
    $statement->bindValue(':datanasc', $datanasc);
    $statement->execute();

    header('Location: index.php');

    
} catch (PDOException $e) {
    // Tratamento de erro...
    echo "Erro ao cadastrar usuário: ".$e->getMessage();
    exit();

}

?>

