
<?php


?>
<?php
// 1. IMPORTANTE: Esse bloco busca os dados na tabela 'cadastro' antes do HTML carregar
require('conexao.php');

try {
    // Faz a consulta para pegar tudo da sua tabela 'cadastro'
    $sql = "SELECT * FROM cadastro";
    $statement = $pdo->prepare($sql);
    $statement->execute();
    
    // Guardamos a lista de registros dentro da variável $lista_cadastro
    $lista_cadastro = $statement->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Erro ao buscar dados do banco: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
       
    <form action="cadastrar.php" method="post" class="mb-5">
        <input class="form-control mb-2" type="text" name="nome" placeholder="Digite seu nome">
        <input class="form-control mb-2" type="text" name="sobrenome" placeholder="Digite seu sobrenome">
        <input class="form-control mb-2" type="date" name="datanasc" placeholder="Digite sua data de nascimento">
        <input type="submit" value="Cadastrar" class="btn btn-primary">
    </form>
    
    <hr>

    <h2>Usuários Cadastrados</h2>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Sobrenome</th>
                <th>Data Nascimento</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lista_cadastro as $cadastro): ?>
                <tr>
                    <td><?php echo $cadastro['id']; ?></td>
                    <td><?php echo $cadastro['Nome']; ?></td>
                    <td><?php echo $cadastro['Sobrenome']; ?></td>
                    <td><?php echo $cadastro['datanasc']; ?></td>
                    <td>
                        <a href="alterar.php?id=<?php echo $cadastro['id']; ?>" class="btn btn-warning btn-sm">Alterar</a>
                        <a href="deletar.php?id=<?php echo $cadastro['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir?')">Deletar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>


